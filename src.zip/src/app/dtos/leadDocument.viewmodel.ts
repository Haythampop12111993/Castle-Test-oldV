export class LeadDocument { 
    id: number = 0;   
    value: string;
    type: string;
    value_date:string
    leadId: number;     
    constructor() {
        this.id = 0;
    }
}
