export class LeadStatus {
    id: number = 0;   
    status: string;
    changeResaon: string;
    leadId: number;
    status_reminder_datetime: any;
    constructor() {
        this.id = 0;
    }
}
