import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-mail-builder',
  templateUrl: './mail-builder.component.html',
  styleUrls: ['./mail-builder.component.css']
})
export class MailBuilderComponent {

  

}
